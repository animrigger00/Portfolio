# Debbie Blackwell Portfolio - Editing Guide

This is a simple, easy-to-edit portfolio website. Here's how to customize it:

## 🔗 How to Edit Links

### Method 1: Edit the JavaScript file (Recommended)
1. Open `script.js` in any text editor
2. Find the `portfolioConfig` object at the top
3. Replace the placeholder URLs with your actual links:

```javascript
const portfolioConfig = {
    // Portfolio button links
    watchAnimation: 'https://your-animation-video-url.com',
    watchJessabee: 'https://your-jessabee-video-url.com',
    watchFrogs: 'https://your-frogs-video-url.com',
    viewGallery: 'https://your-gallery-url.com',
    
    // Social and professional links
    artstation: 'https://digitalworld.artstation.com',
    linkedin: 'https://linkedin.com/in/debbie-blackwell',
    
    // Resume download link
    downloadResume: 'https://your-resume-download-url.com'
};
```

### Method 2: Edit the HTML file directly
1. Open `index.html` in any text editor
2. Find the links you want to change
3. Replace the `href="#"` with your actual URLs

## 🖼️ How to Replace Images

1. Go to the `images/` folder
2. Replace these files with your own images (keep the same names):
   - `3d-character.jpg` - Your 3D character animation image
   - `childrens-media.jpg` - Your children's media image
   - `ai-video.jpg` - Your AI video integration image
   - `concept-art.jpg` - Your concept art image

**Important:** Keep the same file names, or update the `src` attributes in `index.html`

## ✏️ How to Edit Text Content

1. Open `index.html` in any text editor
2. Find the text you want to change:
   - Main title: Look for `<h1 class="main-title">Debbie Blackwell</h1>`
   - Subtitle: Look for the subtitle paragraph
   - Project titles: Look for `<h3 class="item-title">` tags
   - Descriptions: Look for `<p class="item-description">` tags

## 🎨 How to Change Colors and Styling

1. Open `style.css` in any text editor
2. Key colors to change:
   - Background: `#1a1a1a` (dark gray)
   - Accent color: `#00bcd4` (cyan)
   - Purple button: `#8e24aa`
   - Text: `#ffffff` (white)

## 📁 File Structure

```
debbie-portfolio-simple/
├── index.html          # Main HTML file
├── style.css           # All styling
├── script.js           # JavaScript functionality
├── README.md           # This guide
└── images/             # Image folder
    ├── 3d-character.jpg
    ├── childrens-media.jpg
    ├── ai-video.jpg
    └── concept-art.jpg
```

## 🚀 How to Test Your Changes

1. Open `index.html` in any web browser
2. Check that all links work correctly
3. Verify images display properly
4. Test on mobile by resizing your browser window

## 📤 How to Deploy

1. Upload all files to your web hosting service
2. Make sure the folder structure is maintained
3. The main file should be `index.html`

## 💡 Tips

- Always keep backup copies of your files
- Test changes in a browser before deploying
- Images should be optimized for web (under 1MB each)
- Use HTTPS URLs for all external links

## 🆘 Troubleshooting

**Links not working?**
- Check that URLs start with `https://`
- Make sure there are no typos in the JavaScript config

**Images not showing?**
- Verify image files are in the `images/` folder
- Check that file names match exactly (case-sensitive)
- Ensure images are in JPG, PNG, or WebP format

**Page looks broken?**
- Make sure all three files (HTML, CSS, JS) are in the same folder
- Check that file names are correct and haven't been changed

